export const contactList = [
    {
      id: 1,
      name: "Maanvi",
      profilePic: "/profile/profilephoto.jpg",
      lastText: "Hey",
      lastTextTime: "12:58 PM",
    },
    {
      id: 2,
      name: "Thanvi",
      profilePic: "/profile/pp1.jpg",
      lastText: `what going on bro`,
      lastTextTime: "12:45 PM",
    },
    {
      id: 3,
      name: "Anjali",
      profilePic: "/profile/pp2.jpg",
      lastText: "baba lets go out?",
      lastTextTime: "12:30 PM",
    },
    {
      id: 4,
      name: "Kaushal",
      profilePic: "/profile/pp3.jpg",
      lastText: "Typing....",
      lastTextTime: "12:00 PM",
    },
    {
      id: 5,
      name: "Kiran",
      profilePic: "/profile/pp4.jpg",
      lastText: "no broo",
      lastTextTime: "12:00 PM",
    },
    {
      id: 6,
      name: "Anand",
      profilePic: "/profile/pp5.jpg",
      lastText: "no broo",
      lastTextTime: "12:00 PM",
    },
    {
      id: 7,
      name: "Jeeva",
      profilePic: "/profile/pp6.jpg",
      lastText: "no broo",
      lastTextTime: "12:00 PM",
    },
  ];
  export const messagesList = [
    {
      id: 1,
      messageType: "TEXT",
      text: "hello",
      senderID: 0,
      addedOn: "12:00 PM",
    },
    {
      id: 2,
      messageType: "TEXT",
      text: "What's up?",
      senderID: 1,
      addedOn: "12:01 PM",
    },
    {
      id: 3,
      messageType: "TEXT",
      text: "All Good, What about you?",
      senderID: 0,
      addedOn: "12:00 PM",
    },
    {
      id: 4,
      messageType: "TEXT",
      text: "I'm good as well",
      senderID: 1,
      addedOn: "12:00 PM",
    },
    {
      id: 5,
      messageType: "TEXT",
      text: "Great 😁",
      senderID: 0,
      addedOn: "12:00 PM",
    },
    {
      id: 6,
      messageType: "TEXT",
      text: "Please Subscribe to Swathimutyam",
      senderID: 1,
      addedOn: "12:00 PM",
      profilePic: "/profile/pp6.jpg",
    },
    {
      id: 5,
      messageType: "TEXT",
      text: "okay Sure.....",
      senderID: 0,
      addedOn: "12:00 PM",
      fontsize:"10px"
    },
   
  ];
  